sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("authors.authors.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);